package com.example.tabebi.fragments

import androidx.fragment.app.Fragment
import com.example.tabebi.R

class FragmentFirst:  Fragment(R.layout.fragment_first) {
}