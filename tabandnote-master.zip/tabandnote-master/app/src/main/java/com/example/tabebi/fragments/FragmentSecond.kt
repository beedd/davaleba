package com.example.tabebi.fragments

import androidx.fragment.app.Fragment
import com.example.tabebi.R

class FragmentSecond: Fragment(R.layout.fragment_second) {
}